package com.sra.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
